package keywordDataDriven_Framework;

import java.io.FileInputStream;


import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;

public class ReadExcelClass 
{
	public void readExcel(WebDriver driver) throws Exception
	{

		FileInputStream file = new FileInputStream("./POI_Frameworks_1.xlsx");
		XSSFWorkbook w=new XSSFWorkbook(file);
		XSSFSheet s=w.getSheet("KeywordDataDriven");

		int rowSize= s.getLastRowNum();
		System.out.println("No of Keywords: "+rowSize);

		OperationalClass o=new OperationalClass();

		for (int i=1; i<=rowSize; i++)
		{

			String key=s.getRow(i).getCell(0).getStringCellValue();
			System.out.println(key);

			if (key.equals("OpenURL"))
			{
				o.url(driver);
				Thread.sleep(2000);
			}
			else if (key.equals("MaximizeBrowser"))
			{
				o.maximizeBroswer(driver);
				Thread.sleep(2000);
			}
			else if (key.equals("EnterEmail"))
			{
				o.enterEmail(driver, "axyb@gmail.com");
				Thread.sleep(2000);
			}
			else if (key.equals("EnterPassword"))
			{
				o.enterPassword(driver, "Luma222");
				Thread.sleep(2000);
			}
			else if (key.equals("ClickOnLoginButton"))
			{
				o.clickOnLoginButton(driver);
				Thread.sleep(2000);
			}

			else if (key.equals("ClickOnLogoutButton"))
			{
				o.clickOnLogoutButton(driver);
				Thread.sleep(1000);
			}
			else if (key.equals("CloseBroswer"))
			{
				o.closeBroswer(driver);
			}
			w.close();

		}
	}
}


package DataDriven_Framework;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Main_Functionlaties.Luma;


public class Luma_DDT {

	public static void main(String[] args) throws Exception
	{

		FileInputStream file = new FileInputStream("./Luma_DataDriven.xlsx");


		XSSFWorkbook w=new XSSFWorkbook (file);


		XSSFSheet s= w.getSheet("DataDriven");


		int rowsize=s.getLastRowNum();

		System.out.println("No of credential: "+ rowsize);


		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Desktop\\EDU-Data\\Automation Testing\\BrowserExtension\\chromedriver.exe");
		WebDriver driver=new ChromeDriver(); 

		//	Create Object of POM Class
		Luma l = new Luma();

		//For Loop
		for (int i=1; i<=rowsize; i++)
		{

			String Email = s.getRow(i).getCell(0).getStringCellValue();
			String password = s.getRow(i).getCell(1).getStringCellValue();
			System.out.println(Email +"\t\t"+ password);


			try
			{
				l.url(driver);
				Thread.sleep(2000);
				l.maximizeBroswer(driver);
				Thread.sleep(2000);
				l.enterEmail(driver, Email);
				Thread.sleep(2000);
				l.enterPassword(driver, password);
				Thread.sleep(2000);
				l.clickOnLoginButton(driver);
				Thread.sleep(2000);
				l.clickOnLogoutButton(driver);
				Thread.sleep(3000);


				System.out.println("valid Credential.");
				s.getRow(i).createCell(2).setCellValue("valid Credential.");

			}
			catch (Exception e)
			{

				System.out.println("Invalid Credential.");
				s.getRow(i).createCell(2).setCellValue("Invalid Credential.");
			}


		}


		FileOutputStream out = new FileOutputStream("./Luma_DataDriven.xlsx");
		w.write(out);

		driver.close();
		w.close();
	}

}

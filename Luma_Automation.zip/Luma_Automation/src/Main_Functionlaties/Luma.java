package Main_Functionlaties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Luma {
	
	public void maximizeBroswer(WebDriver driver)
	{
		driver.manage().window().maximize();
	}

	public void url(WebDriver driver)
	{
		driver.get("https://luma.enablementadobe.com/content/luma/us/en/community/signin.html");
	}

	public void enterEmail(WebDriver driver, String email)
	{
		driver.findElement(By.name("j_username")).sendKeys(email);
	}

	public void  enterPassword(WebDriver driver, String pwd)
	{
		driver.findElement(By.name("j_password")).sendKeys(pwd);
	}

	public void clickOnLoginButton(WebDriver driver)
	{
		driver.findElement(By.xpath("//button[@type='submit']")).submit();
	}
	
	public void clickOnLogoutButton(WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"top\"]/div[1]/div/ul[2]/li[7]/a")).click();
	}
	
	public void closeBroswer(WebDriver driver)
	{
		driver.close();
	}



}

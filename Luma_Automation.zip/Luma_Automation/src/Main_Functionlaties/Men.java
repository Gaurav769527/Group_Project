package Main_Functionlaties;

import java.util.Scanner;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Men {

	public static void main(String[] args) throws Exception
	{
	
		Scanner s=new Scanner(System.in);
		System.out.println("Enter Email: ");
		String Email=s.next();
		System.out.println("Enter Password");
		String pwd=s.next();
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Desktop\\EDU-Data\\Automation Testing\\BrowserExtension\\chromedriver.exe");

		WebDriver driver=new ChromeDriver(); 
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		Thread.sleep(2000);
		driver.get("https://luma.enablementadobe.com/content/luma/us/en.html");
		
		Thread.sleep(2000);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"top\"]/div[1]/div/ul[2]/li[2]/a")).click();
		
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@placeholder='Email']")).sendKeys(Email);
				
		Thread.sleep(2000);
				
		driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys(pwd);
				
		Thread.sleep(2000);
				
		driver.findElement(By.xpath("//button[@type='submit']")).submit();
		
		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"navigation-fd3cee8df8\"]/ul/li[2]/a")).click();
		
		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"page-e590d8a77d\"]/div[1]/div/div/div[2]/div/div/div/p[2]/a")).click();
		
		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"page-7cfb237d1e\"]/div[1]/div/div/div[5]/div/div[1]/div/a")).click();
		
		Thread.sleep(2000);
		
		WebElement element=driver.findElement(By.xpath("//*[@id=\"page-d514571e48\"]/div[1]/div/div/div[4]/div/div[1]/div/div[3]/div/div/div[1]"));
		
		js.executeScript("arguments[0].scrollIntoView()",element);
		
		s.close();

	}

}

package Main_Functionlaties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MainClass_Luma {

	public static void main(String[] args) throws Exception
	{
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Desktop\\EDU-Data\\Automation Testing\\BrowserExtension\\chromedriver.exe");

		WebDriver driver=new ChromeDriver(); 
		
		Luma l=new Luma();
		
		l.maximizeBroswer(driver);
		l.url(driver);
		
		Thread.sleep(2000);
		l.enterEmail(driver, "axyb@gmail.com");
		l.enterPassword(driver, "Luma222");
		
		Thread.sleep(2000);
		l.clickOnLoginButton(driver);
		
		Thread.sleep(2000);
		l.clickOnLogoutButton(driver);
		
		Thread.sleep(2000);
		l.closeBroswer(driver);

	}

}
